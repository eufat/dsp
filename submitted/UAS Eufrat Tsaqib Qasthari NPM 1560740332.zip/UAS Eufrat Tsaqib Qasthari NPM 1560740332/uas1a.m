b = [1]; a=[1,0,1/3];
[R, p, C] = residuez(b,a)
    