b = [0.4,-0.4]; a=[1,0.2];
[R, p, C] = residuez(b,a)
